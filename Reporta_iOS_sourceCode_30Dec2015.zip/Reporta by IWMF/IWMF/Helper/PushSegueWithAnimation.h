//
//  PushSegueWithAnimation.h
//  IWMF


#import <UIKit/UIKit.h>

@interface PushSegueWithAnimation : UIStoryboardSegue

@end
