//
//  Entity+CoreDataProperties.swift
//  IWMF
//
//  Created by Pavan on 12/16/15.
//  Copyright © 2015 Mac 10. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension Entity {

//    @NSManaged var userData: NSData?
//    @NSManaged var checkinData: NSData?

}
