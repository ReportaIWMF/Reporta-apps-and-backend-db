//
//  ApplicationData.swift
//  IWMF
//
//

import Foundation
import CoreData

@objc(ApplicationData)
class ApplicationData: NSManagedObject {

// Insert code here to add functionality to your managed object subclass
    @NSManaged var appData: NSData?

}
