package com.iwmf.http;

/**
 * <p> Enum of Reporta supported languages. </p>
 */
public enum LanguageCodes {
    EN, ES, AR, IW, TR, FR
}
