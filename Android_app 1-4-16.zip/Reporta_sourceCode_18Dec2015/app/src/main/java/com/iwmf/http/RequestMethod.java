package com.iwmf.http;

/**
 * <p> Enum for request method. </p>
 */
public enum RequestMethod {
    GET, POST
}
