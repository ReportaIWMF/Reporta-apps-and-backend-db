package com.iwmf.utils;

/**
 * <p> Enum for supported language codes. </p>
 */
public enum Language_code {
    EN, AR, ES, FR, IW, TR
}
